public class StringToDouble  {
    public Double transform(String str) {
        return Double.valueOf(str);
    }
}
