public class StringToInteger {
    public Integer transform(String str) {
        return Integer.valueOf(str);
    }
}
